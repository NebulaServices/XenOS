(async () => {
    console.log(
        await window.xen.net.fetch('https://example.com')
    )
});